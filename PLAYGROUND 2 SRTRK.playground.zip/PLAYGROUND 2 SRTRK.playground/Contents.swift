let numero1 = 7
let numero2 = 11
let suma = 5 + 2
let a = 4
let b = 3
let c = 4
let d = a + b + c
print (d)
let multiplicacion = 3 * 7
var multiplicacion = 3 * 7
let div = 16 / 4
let a = 6
let b = 2
let esMayor = a > b
var numeros [Int] :[2,1,5,4,3]
let cantidadNumero = numeros.count
let primerNumero = numeros [0]
let numerosOrdenados
Ejercicio 10
let clima = "Soleado"
switch clima {
case "Soleado":
}
