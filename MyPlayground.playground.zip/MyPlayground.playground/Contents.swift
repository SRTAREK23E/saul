import UIKit

var saludo = "Hola Mundo"
let nombre = "Saul"
let /* "Saul
     Ciencias poticas y administracion publica
     diecinueve años*/
let cadena = "Cadena
let boleano = "true"
let entero = 22
let edad = 19
let luzprendida = TRUE
let persona: (String, Int) = (nombre= "Saul", edad= 19)
var distancia =
var peso =
let curso =
let SANDIA =
let nombre: String = "Saul"
let tradicion: Dia de muertos
var 22_cuadrada = 484
/* ejercicio 6
 */
var fuerza = 40
let nombre = "Saul"
let apellido = "Reyes"
var edad = 19
