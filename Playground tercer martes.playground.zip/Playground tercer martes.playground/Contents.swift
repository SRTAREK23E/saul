//Ejercicio 1 for, while, y repeat)
//for i in 1 ... 10 {
//    print (i)
//}
//var contador = 1
//while contador < 10{
//        print ("El contador es \(contador) ")
//contador += 1
//}
//repeat {
//    print("El contador es \(contador)")
//    contador += 1
//} while contador < 5
// me falta ejercicio 3//
//Ejercicio 4 //


